/* Portas didáticas para exploração. A evidência acadêmica permanece no Python.
   Ordem de desempate preservada. Prim usa fronteira ordenada, não heap. */
(function(root){'use strict';
const cmp=(a,b)=>a<b?-1:a>b?1:0;
const tuple=(a,b)=>{for(let i=0;i<Math.min(a.length,b.length);i++){const c=cmp(a[i],b[i]);if(c)return c;}return a.length-b.length;};
function mst(vertices,edges,algo='kruskal'){
 const tree=[],trace=[],parent=Object.fromEntries(vertices.map(v=>[v,v])),size=Object.fromEntries(vertices.map(v=>[v,1]));
 const find=v=>{while(parent[v]!==v){parent[v]=parent[parent[v]];v=parent[v];}return v;};
 if(algo==='kruskal')for(const [u,v,w] of [...edges].sort((a,b)=>tuple([a[2],a[0],a[1]],[b[2],b[0],b[1]]))){let a=find(u),b=find(v);trace.push([u,v,w,a!==b?'ACEITA':'CICLO']);if(a!==b){if(size[a]<size[b])[a,b]=[b,a];parent[b]=a;size[a]+=size[b];tree.push([u,v,w]);}}
 else {const seen=new Set(),adj=Object.fromEntries(vertices.map(v=>[v,[]]));edges.forEach(([u,v,w])=>{adj[u].push([w,u,v]);adj[v].push([w,v,u]);});for(const r of ['BASE',...vertices.filter(v=>v!=='BASE')].filter(v=>v in adj)){if(seen.has(r))continue;seen.add(r);const q=[...adj[r]];while(q.length){q.sort(tuple);const [w,u,v]=q.shift(),yes=!seen.has(v);trace.push([u,v,w,yes?'ACEITA':'VISITADO']);if(yes){seen.add(v);tree.push([u,v,w]);q.push(...adj[v]);}}}}
 return {tree,trace,custo:tree.reduce((a,e)=>a+e[2],0),componentes:vertices.length-tree.length};
}
function huffman(seq){let counter=0;const freq={};seq.forEach(s=>freq[s]=(freq[s]||0)+1);const q=Object.entries(freq).map(([s,f])=>({f,order:counter++,s:Number(s)})),merges=[];
 while(q.length>1){q.sort((a,b)=>tuple([a.f,a.order],[b.f,b.order]));const a=q.shift(),b=q.shift();merges.push([a.f,b.f,a.f+b.f]);q.push({f:a.f+b.f,order:counter++,esq:a,dir:b});}
 const tree=q[0]||null,codes={};function walk(n,c){if(!n)return;if(n.s!==undefined)codes[n.s]=c||'0';else{walk(n.esq,c+'0');walk(n.dir,c+'1');}}walk(tree,'');const bits=seq.map(s=>codes[s]).join(''),dict=Object.values(codes).reduce((a,c)=>a+2+Math.ceil(c.length/8),0);const inv=Object.fromEntries(Object.entries(codes).map(([k,v])=>[v,Number(k)]));let prefix='',decoded=[];for(const bit of bits){prefix+=bit;if(prefix in inv){decoded.push(inv[prefix]);prefix='';}}
 return{tree,codes,merges,bits,dict,decoded,bytes:11+dict+Math.ceil(bits.length/8)+4,fixo:6+Math.ceil(3*seq.length/8)+4};
}
function bst(events){let tree=null,visits=0;for(const e of events){const n={e,key:[e.instante_ms,e.id],esq:null,dir:null};if(!tree){tree=n;continue;}let p=tree;while(p){visits++;const side=tuple(n.key,p.key)<0?'esq':'dir';if(!p[side]){p[side]=n;break;}p=p[side];}}
 let height=-1,stack=[[tree,0]];while(stack.length){let[n,h]=stack.pop();if(n){height=Math.max(height,h);stack.push([n.esq,h+1],[n.dir,h+1]);}}return{tree,height,visits};}
function traversal(tree,order='em'){const out=[],stack=[[tree,false]];while(stack.length){let[n,emit]=stack.pop();if(!n)continue;if(emit){out.push(n.e);continue;}const items={em:[[n.dir,false],[n,true],[n.esq,false]],pre:[[n.dir,false],[n.esq,false],[n,true]],pos:[[n,true],[n.dir,false],[n.esq,false]]};stack.push(...items[order]);}return out;}
function interval(tree,start,end){if(start>end)throw Error('Intervalo invertido');let n=tree,stack=[],out=[];while(n||stack.length){while(n){if(n.key[0]<start)n=n.dir;else{stack.push(n);n=n.esq;}}if(!stack.length)break;n=stack.pop();if(n.key[0]>end)break;out.push(n.e);n=n.dir;}return out;}
function kdBuild(points,depth=0){if(!points.length)return null;const axis=depth%2,p=[...points].sort((a,b)=>tuple([a[1][axis],a[0]],[b[1][axis],b[0]])),mid=Math.floor(p.length/2);return{id:p[mid][0],point:p[mid][1],axis,esq:kdBuild(p.slice(0,mid),depth+1),dir:kdBuild(p.slice(mid+1),depth+1)};}
function kdQuery(tree,q){let best=[Infinity,Infinity,null],visits=[];function visit(n){if(!n)return;visits.push(n.id);const d=n.point.reduce((a,x,i)=>a+(x-q[i])**2,0);if(tuple([d,n.id],best.slice(0,2))<0)best=[d,n.id,n.point];const delta=q[n.axis]-n.point[n.axis],near=delta<0?'esq':'dir',far=delta<0?'dir':'esq';visit(n[near]);if(delta*delta<=best[0])visit(n[far]);}visit(tree);return{v:best[2]?[best[1],best[2],Math.sqrt(best[0])]:null,n:visits.length,visits};}
function kdRadius(tree,q,r){let out=[];function visit(n){if(!n)return;if(Math.hypot(n.point[0]-q[0],n.point[1]-q[1])<=r)out.push(n.id);let d=q[n.axis]-n.point[n.axis];if(d<=r)visit(n.esq);if(d>=-r)visit(n.dir);}visit(tree);return out.sort((a,b)=>a-b);}
function fire(mark,t){if(!mark.every((v,i)=>v>=t[0][i]))throw Error('Transição não habilitada');return mark.map((v,i)=>v-t[0][i]+t[1][i]);}
function predict(tree,x,id3=false){if(!x.every(Number.isFinite))throw Error('Dado inválido');let node=tree,path=[];let values=x;if(id3){const[p,q,b,w]=x;values=[p<1?'BAIXA':p>5?'ALTA':'NORMAL',q<.5?'BAIXA':'NORMAL',b<20?'BAIXA':'NORMAL',w>8?'ALTO':'NORMAL'];}while(node.feature!==undefined){const key=id3?values[node.feature]:(values[node.feature]<=node.limiar?'esq':'dir');path.push({node,key,value:values[node.feature]});const next=id3?node.filhos[key]:node[key];if(!next)break;node=next;}return{classe:node.classe,path,leaf:node};}
root.AGRO_ALG={mst,huffman,bst,traversal,interval,kdBuild,kdQuery,kdRadius,fire,predict};
})(typeof window!=='undefined'?window:globalThis);
