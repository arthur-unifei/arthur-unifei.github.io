# Integração — Apresentação da Etapa 03

**SCADA · AgroDrone — UNIFEI / ECAA08 / Grupo 06**  
Arthur, Caique, Luis Felipe e Marina. Entrega de 25/11/2026.

## Abrir para apresentar

1. Extraia **todo o ZIP** para uma pasta. Não abra o HTML dentro do compactador.
2. Abra `etapa-03-arvores.html` no Chrome, Edge ou Firefox atualizado.
3. Clique em **Iniciar apresentação**. Use os números ou as setas para navegar. **F** ativa a projeção; **Esc** sai. O botão de tela cheia usa a API do navegador, com modo de projeção como alternativa quando a API é indisponível.
4. Em cada slide técnico, **Abrir experimento** leva ao laboratório; **Voltar ao slide** retorna ao slide de origem.
5. A missão integrada dispõe de reprodução, pausa, anterior, próximo, seleção de snapshot e reinício.

O HTML depende das pastas entregues. Não mova somente o HTML. Dados, scripts, diagramas e fontes são locais; a aplicação não precisa de Python, backend ou CDN. Os links externos e a consulta ao GitHub precisam de internet. O CSS compartilhado original contém uma importação Google Fonts; cópias locais das fontes são declaradas depois dele, mantendo a apresentação utilizável sem essa conexão.

## Adicionar ao repositório existente

O conteúdo do ZIP corresponde à **raiz do repositório**, e não a uma subpasta adicional:

- `etapa-03-arvores.html`: página nova.
- `assets/etapa-03.css`, `assets/etapa-03-fontes.css`: estilos novos.
- `assets/etapa-03.js`, `assets/etapa-03-algoritmos.js`, `assets/etapa-03-dados.js`: interface, algoritmos e evidências.
- `assets/fonts/`: fontes locais e licenças.
- `Apresentacao_Apoio/`: instruções, rastreabilidade e testes da apresentação.
- `etapa-03-arvores/`: os 48 arquivos acadêmicos do ZIP fornecido, preservados byte a byte.
- `assets/style.css`: cópia sem alteração da referência compartilhada consultada.

**Faça a mesclagem das pastas, não substitua a pasta `assets` inteira.** Se `assets/style.css` já existe, preserve a versão do repositório; a cópia entregue é para execução local. Se o repositório mudou desde a referência, confira o visual com seu CSS atual antes de publicar.

Não substitua documentos acadêmicos que tenham sido atualizados posteriormente. Compare-os com `Manifesto_Originais.json`; esta entrega não resolve alterações posteriores ao ZIP de referência. Adicione as aulas 27 e 28 e demais arquivos ausentes a partir da pasta acadêmica entregue.

As páginas `index.html` e `etapa-02-grafos.html` não são incluídas nem modificadas. Seus links relativos passam a funcionar quando esta entrega é mesclada ao repositório existente. No pacote isolado, use diretamente `etapa-03-arvores.html`; os dois links de etapas anteriores dependem desses arquivos do repositório.

## Publicar no GitHub Pages

1. Faça upload/commit dos arquivos novos na mesma branch e pasta já utilizadas pelo GitHub Pages.
2. Preserve as configurações atuais em **Settings → Pages**. Não é necessário criar outro site.
3. Após o deploy, abra o endereço do site existente seguido de `/etapa-03-arvores.html`.
4. Confira as cinco abas, um slide em projeção e a missão integrada no dispositivo da apresentação.
5. Opcionalmente, adicione nas navegações anteriores apenas o link relativo `<a href="etapa-03-arvores.html">03 · Árvores</a>`. Esta entrega não modifica essas páginas automaticamente.

Nenhuma alteração foi publicada diretamente no GitHub.

## Reproduzir as verificações

**Algoritmos JavaScript** — Node.js, sem dependências:

```bash
node Apresentacao_Apoio/testar_algoritmos.cjs
```

**Controles DOM** — teste adicional; não é necessário para abrir a apresentação:

```bash
npm install --prefix Apresentacao_Apoio --no-save jsdom@26
node Apresentacao_Apoio/testar_interface.cjs
```

Não envie `node_modules/` ao repositório. O teste DOM não substitui inspeção em navegador.

**Reexportar dados do Python** — execute na raiz desta entrega:

```bash
python Apresentacao_Apoio/exportar_dados.py
```

A exportação usa os módulos acadêmicos e atualiza `assets/etapa-03-dados.js`. Ela não deve ser usada para misturar silenciosamente outra versão dos dados com os resultados registrados: após mudanças acadêmicas, reexecute as verificações e atualize os relatórios. A validação dos notebooks utiliza o script original em `etapa-03-arvores/Arquivos_de_Apoio/validar_notebooks.py`; consulte o README acadêmico para suas opções. Para preservar os registros originais, execute-o em uma cópia de trabalho, como foi feito nesta entrega.
