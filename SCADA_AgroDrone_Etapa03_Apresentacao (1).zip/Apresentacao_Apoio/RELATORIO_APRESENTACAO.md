# Relatório técnico da apresentação — 25/11/2026

## Entrega e referência

Apresentação didática do **Sistema SCADA aplicado a um Drone Agrícola de Pulverização**, Grupo 06, UNIFEI/ECAA08. São cinco abas, 14 slides e dez módulos de laboratório, referentes às aulas 19–28. Não se trata de conexão com hardware real.

A fonte acadêmica é o ZIP anexado `Etapa_03_SCADA_Drone_Completa(1).zip`. Foram examinados os documentos, notebooks, módulos, cenário, catálogo, CSVs, resultados e figuras. Os 48 arquivos acadêmicos são preservados. O manifesto SHA-256 permite comparar a cópia entregue com o anexo.

As apresentações públicas das Etapas 01 e 02 e seus arquivos `assets/style.css`, `assets/etapa-02.css`, `assets/etapa-02.js` e `assets/script.js` orientaram estrutura e aparência. A Etapa 02 foi inspecionada também em navegador, inclusive projeção e laboratório. Seus resultados experimentais não foram usados como resultados da Etapa 03.

## Reexecução Python

- **10 notebooks, 56 células de código**, concluídos pelo validador original em cópia separada.
- Cada notebook executado sequencialmente em um processo Python novo; formato verificado com nbformat.
- Os dez resumos resultantes coincidiram com os resumos acadêmicos registrados.
- Ambiente: Python 3.12.14, matplotlib 3.10.8, nbformat 5.11.1.
- Evidência estruturada: `Reexecucao_Python.json`.
- A tentativa de execução com kernel Jupyter falhou por restrição de sockets do ambiente (`Operation not permitted`, `ip_resolver.cpp`). Portanto não se declara validação via kernel Jupyter.
- **56 células não equivalem a 56 testes.** Não foi inventada uma contagem de asserções aprovadas.

## Validação dos algoritmos da apresentação

`testar_algoritmos.cjs` compara as portas JavaScript com dados exportados da implementação Python:

| Módulo | Comparação executada |
|---|---|
| AGM | 512 subconjuntos das nove arestas; Kruskal e Prim; árvore, custo e componentes |
| Huffman | Três blocos; códigos, fusões, recuperação e contabilização de bytes |
| BST | Seis ordens/tamanhos; alturas, visitas, percursos e intervalos |
| KD | 100 consultas da instância de 402 pontos; vizinho, raio e visitas |
| Petri | Oito transições e rejeição de disparos não habilitados |
| Decisão | 600 amostras, cada uma nos dois modelos, contra predições Python |

Resultado: aprovado. Esses números são comparações adicionais da apresentação; não aumentam a contagem acadêmica. Veja `Validacao_JavaScript.json`.

RRT, STP, comportamento e missão integrada são **replays de saídas Python**, identificados na interface. O navegador não reinventa amostras aleatórias nem executa um controlador físico. A árvore de decisão é treinada em Python; apenas sua inferência é calculada em JavaScript. No Huffman, a recuperação JS utiliza os códigos de prefixos; o pacote binário e o CRC completo continuam como evidências da execução Python.

## Testes de interface e revisão visual

**Navegador Chrome real, viewport aproximadamente 1363 × 936:**

- Página carregada com fontes, SVGs e navegação.
- Modo de projeção acionado pelo botão; saída pelo botão também verificada. A API nativa teve fallback para projeção, portanto não se certifica a tela cheia nativa.
- Índice percorreu os 14 slides. Medição DOM não indicou transbordamento horizontal; o corpo dos slides coube na área disponível em projeção.
- Inspeção visual de introdução, conclusão e slide de árvores de decisão, além do painel integrado no cenário de obstrução.
- Todos os dez módulos abriram e apresentaram conteúdo específico, controles e resultados.
- Na missão: seleção de obstrução, avanço à falha retida, reinício e acionamento da reprodução.
- Os registros de console consultados continham erros de uma extensão do ambiente; não eram mensagens do JavaScript da apresentação. Essa amostra não permite afirmar ausência global de erros em todas as condições.

A revisão visual final foi interrompida depois da retomada do ambiente por um bloqueio de acesso do navegador à página de prévia. Não houve tentativa de contornar o bloqueio. Os ajustes finais de rótulos acessíveis, setas de Petri e destaque da folha de decisão foram verificados em código/DOM, **sem nova inspeção visual final**.

**Testes DOM automatizados (jsdom 26):** cinco abas; 14 slides e atalhos; ambos os algoritmos de AGM; cenários e recuperação Huffman; ordens, percursos e consultas BST; 14 cenários RRT; cinco topologias STP e duas linhas de tempo; disparos/desfazer e árvores Petri; 16 casos de comportamento; KD; dois modelos em 100 amostras de teste; e todos os snapshots da missão com bomba, avanço, retrocesso, reprodução, pausa e reset. Resultado em `Validacao_Interface_DOM.json`. O temporizador é controlado pelo teste para verificar sua lógica, não sua precisão de tempo real.

**Verificações estáticas:** sintaxe dos scripts; existência dos recursos locais renderizados; correspondência SHA-256 dos 48 originais; presença de fontes e licenças. As únicas dependências locais intencionalmente externas ao pacote são `index.html` e `etapa-02-grafos.html`, presentes no repositório de destino. Links GitHub de código pressupõem a publicação dos arquivos nos mesmos caminhos.

**Não verificado integralmente:** todos os controles em navegador real, todas as abas em revisão visual, redimensionamento em celular, funcionamento em Safari/Firefox/Edge, modo `file://` real, rede desconectada, todos os links externos, tela cheia nativa e deploy no GitHub Pages. CSS responsivo e recursos locais foram implementados, mas não são apresentados como testes visuais aprovados. Faça a conferência final no notebook/projetor da sala.

## Limitações e decisões preservadas

- AGM é referência de conectividade; não é missão completa nem autorização da bomba.
- Mapa planar e obstáculos estáticos; raio 0,6 m + margem 1,4 m são hipóteses ilustrativas. Não representam dimensões medidas de um drone.
- RRT não modela dinâmica, consumo, vento ou cobertura. Fracasso com orçamento finito não prova impossibilidade geral.
- STP considera a LAN da estação, sem tratar o drone como switch. 30 s e 0,04 s são tempos ilustrativos do modelo, não medições. STP não é AGM.
- Petri representa fases; permissivos físicos ficam fora da rede P/T. ω descreve crescimento não limitado da fila.
- A classificação aprendida é consultiva e sintética. Não substitui intertravamentos e não rearma falhas.
- A posição da missão assume BASE/T1 por fase; não há animação que sugira voo contínuo medido. Bateria e nível são snapshots, não consumo integrado.
- O histórico original registra esperas como PAUSA e solicitações de aplicação como INICIO_FAIXA. A apresentação mantém a simplificação, distinguindo-a de novos inícios físicos de faixa.
- `bomba_feedback` é entrada independente do comando final. Ambos são mostrados separadamente para não simular uma dinâmica inexistente.

## Arquivos adicionados ou modificados

**Novos:** página HTML; três scripts de dados/algoritmos/interface; dois CSS específicos; fontes locais e licenças; esta documentação, instruções, manifesto e resultados/scripts de exportação e teste em `Apresentacao_Apoio/`.

**Copiados sem alterações:** `assets/style.css` e os 48 arquivos da pasta acadêmica `etapa-03-arvores/`. Os arquivos das Etapas 01/02, o README acadêmico, os notebooks e o código Python original não foram editados. Não foi feita publicação externa.
