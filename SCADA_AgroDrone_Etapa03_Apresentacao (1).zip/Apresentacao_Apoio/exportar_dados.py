"""Exporta evidências para a apresentação sem alterar os arquivos acadêmicos."""
from pathlib import Path
import sys,json,math,random,inspect,ast,hashlib,csv,copy
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'etapa-03-arvores';AP=SRC/'Arquivos_de_Apoio'
sys.path.insert(0,str(AP));import scada_arvores as s

def limpo(x):
    if isinstance(x,float) and not math.isfinite(x):return 'ω' if x==math.inf else 'NaN'
    if isinstance(x,dict):return {str(k):limpo(v) for k,v in x.items()}
    if isinstance(x,(list,tuple,set,frozenset)):return [limpo(v) for v in x]
    return x

def dados():
    d={'config':s.CONFIG,'catalogo':json.loads((AP/'catalogo_aulas.json').read_text()),'registrado':json.loads((AP/'Resultados_Validacao.json').read_text()),'eventos':s.EVENTOS,'classes':s.CLASSES,'features':s.FEATURES}
    es=s.arestas_mapa();vs=list(s.PONTOS)
    d['mst']={'edges':es,'fixtures':[]}
    for mask in range(1<<len(es)):
        e=[a for i,a in enumerate(es) if mask&(1<<i)]
        k,kt=s.kruskal(vs,e);p,pt=s.prim(vs,e)
        d['mst']['fixtures'].append({'mask':mask,'k':k,'p':p,'custo':s.custo(k),'componentes':len(s.componentes(vs,e))})
    ev=s.gerar_eventos();d['historico']=ev
    d['huffman']=[]
    for nome,seq in [('Histórico • 194 eventos',[e['tipo'] for e in ev]),('Mensagem curta',[0,1,3,5]),('Distribuição equilibrada',list(range(6))*10)]:
        tree,cod,fus=s.huffman(seq);p=s.comprimir(seq);fixed=s.fixo(seq)
        d['huffman'].append(dict(nome=nome,seq=seq,tree=tree,cod=cod,fusoes=fus,bytes=len(p),fixo=len(fixed),hex=p.hex(),recuperado=s.descomprimir(p)))
    d['bst']={}
    for tamanho in [12,194]:
        rows=ev[:tamanho];mix=list(rows);random.Random(21).shuffle(mix)
        d['bst'][str(tamanho)]=[]
        for nome,order in [('Embaralhada',mix),('Cronológica',rows),('Mediana-primeiro',s.ordem_mediana(rows))]:
            h=s.Historico();visitas=sum(h.inserir(e) for e in order)
            d['bst'][str(tamanho)].append(dict(nome=nome,order=[e['id'] for e in order],altura=h.altura(),visitas=visitas,percursos={o:[e['id'] for e in h.percurso(o)] for o in ['em','pre','pos']}))
    d['rrt']=[]
    casos=[('Referência • semente 22',22,2500,s.OBSTACULOS,s.PONTOS['BASE'])]+[(f'Semente {i}',i,2500,s.OBSTACULOS,s.PONTOS['BASE']) for i in range(10)]+[('Barreira total • 300 iterações',22,300,[(75,95,-20,210)],s.PONTOS['BASE']),('Orçamento zero',22,0,s.OBSTACULOS,s.PONTOS['BASE']),('Início inválido',22,2500,s.OBSTACULOS,(80,50))]
    for nome,seed,budget,obs,start in casos:
        r=s.rrt(start,s.PONTOS['T1'],seed=seed,max_iter=budget,obstaculos=obs)
        d['rrt'].append(dict(nome=nome,seed=seed,budget=budget,obstaculos=obs,inicio=start,**r,comprimento=s.comprimento(r['caminho'])))
    d['stp']={'bridges':s.BRIDGES,'links':s.LINKS,'casos':[],'tempos':{p:s.convergencia(p) for p in ['STP','RSTP']}}
    for nome,ls in [('Nominal',s.LINKS)]+[(f'Falha {u}–{v}',s.LINKS[:i]+s.LINKS[i+1:]) for i,(u,v,_) in enumerate(s.LINKS)]+[('LAN particionada',[])]:
        d['stp']['casos'].append(dict(nome=nome,links=ls,**s.spanning_tree(ls)))
    rede,m=s.rede_missao();d['petri']={'lugares':s.LUGARES,'arcos':s.ARCOS,'transicoes':rede,'marcas':s.atingibilidade(rede,m)[0],'arvore':s.arvore_atingibilidade(rede,m),'cobertura':s.cobertura({'produzir':((1,0),(1,1)),'confirmar':((0,1),(0,0))},(1,0))}
    d['bt']=[]
    casos=[('Nominal',{}),('Vento alto',{'EST_WT_01':9}),('Bateria crítica',{'DRN_ET_01':9}),('Nível crítico',{'DRN_LT_01':4}),('GPS inválido',{'gps_ok':False}),('Sem comunicação',{'comm_ok':False}),('Telemetria vencida',{'idade_s':3}),('Emergência',{'e_stop':True}),('Altitude inválida',{'alt_ok':False}),('Modos conflitantes',{'auto_mode':True,'manual_mode':True}),('Vazão NaN',{'DRN_FT_01':float('nan')}),('Fora de voo',{'is_flying':False})]
    for nome,changes in casos:
        bb=dict(aprovada=True,rota_ok=True,na_faixa=True);t=s.telemetria(**changes);r=s.tick_supervisor(bb,t)
        d['bt'].append(dict(nome=nome,t=t,bb=bb,resultado=r))
    bb=dict(aprovada=True,rota_ok=True,na_faixa=True);d['rearme']=[]
    for nome,t,op in [('Obstrução',s.telemetria(DRN_PT_01=5.5,DRN_FT_01=.2),{}),('Sintoma desapareceu',s.telemetria(bomba_feedback=False,DRN_FT_01=0),{}),('Rearme sem inspeção',s.telemetria(),{'rearme':True}),('Inspeção e rearme',s.telemetria(),{'rearme':True,'inspecao_confirmada':True})]:
        bb.update(op);r=s.tick_supervisor(bb,t);d['rearme'].append(dict(nome=nome,t=t,bb=copy.deepcopy(bb),resultado=r))
    pts=list(enumerate(s.PONTOS.values()));d['kd']={'mapa':pts,'fixtures':[]}
    rng=random.Random(26);pontos=[(i,(rng.uniform(-10,10),rng.uniform(-10,10))) for i in range(400)]+[(400,(0.,0.)),(401,(0.,0.))];tree=s.kd_construir(pontos)
    for _ in range(100):
        q=(rng.uniform(-12,12),rng.uniform(-12,12));v,n=s.kd_vizinho(tree,q)
        d['kd']['fixtures'].append(dict(q=q,v=v,n=n,raio=s.kd_raio(tree,q,3)))
    d['kd']['pontos_teste']=pontos
    exp=s.experimento_classificacao();treino=[v for v in exp['dados'] if v['missao']%6<4];teste=[v for v in exp['dados'] if v['missao']%6==5]
    id3=s.id3([s.categorizar(v['x']) for v in treino],[v['y'] for v in treino]);exp['id3']=id3;exp['metricas_id3']=s.metricas([v['y'] for v in teste],[s.prever_id3(id3,s.categorizar(v['x'])) for v in teste]);exp['previsoes']=[s.prever(exp['modelo'],v['x']) for v in exp['dados']];exp['previsoes_id3']=[s.prever_id3(id3,s.categorizar(v['x'])) for v in exp['dados']];d['decisao']=exp
    # Instrumentação da função original, sem mudar entradas, política ou resultados.
    original=s.tick_supervisor;capturas=[]
    def capturar(bb,t):
        antes=copy.deepcopy(bb);r=original(bb,t);capturas.append(dict(t=copy.deepcopy(t),antes=antes,bb=copy.deepcopy(bb),resultado=copy.deepcopy(r)));return r
    s.tick_supervisor=capturar
    try:d['sim']=s.simular_missao(exp['modelo'])
    finally:s.tick_supervisor=original
    d['sim']['capturas']=capturas
    csvs=list(csv.DictReader((AP/'Telemetria_Simulacao.csv').open()))
    assert len(csvs)==len(d['sim']['linhas'])
    for a,b in zip(csvs,d['sim']['linhas']):
        for k,v in b.items():assert str(v)==a[k],(k,v,a[k])
    df=list(csv.DictReader((AP/'Dados_Classificacao.csv').open()))
    assert len(df)==len(exp['dados'])
    for a,b in zip(df,exp['dados']):
        assert [float(a[k]) for k in s.FEATURES]==b['x'] and a['classe']==s.CLASSES[b['y']]
    d['codigo']={}
    for numero,nomes in {19:['kruskal','prim'],20:['huffman','comprimir','descomprimir'],21:['Historico'],22:['rrt','segmento_livre'],23:['spanning_tree','convergencia'],24:['atingibilidade','cobertura'],25:['arvore_comportamento','tick_supervisor'],26:['kd_construir','kd_vizinho'],27:['treinar_arvore','id3'],28:['simular_missao']}.items():
        d['codigo'][str(numero)]=[{'nome':n,'texto':inspect.getsource(getattr(s,n)),'linha':inspect.getsourcelines(getattr(s,n))[1]} for n in nomes]
    d['arquivos']=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(SRC.rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
    return limpo(d)
if __name__=='__main__':
    d=dados();out=ROOT/'assets/etapa-03-dados.js';out.write_text('window.AGRO_DATA = '+json.dumps(d,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')
    print(out.name,out.stat().st_size,'bytes; CSVs comparados com Python.')
